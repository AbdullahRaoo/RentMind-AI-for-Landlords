import Chatbot from "@/components/chatbot"

export default function Home() {
  return <Chatbot />
}
